package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

public class DemoApplication {
	public static void main(String[] args) {
		AddressController addressController = new AddressController();
		Address address1 = addressController.createAddress("123 Main St", 12345);
		Address address2 = addressController.createAddress("456 Oak Ave", 67890);
		System.out.println(addressController.getAllAddresses());

		BuildingController buildingController = new BuildingController();
		Building building1 = buildingController.createBuilding("2021-01-01", "house");
		Building building2 = buildingController.createBuilding("2022-02-02", "apartment");
		System.out.println(buildingController.getAllBuildings());

		addressController.deleteAddress(address1);
		System.out.println(addressController.getAllAddresses());

		buildingController.deleteBuilding(building2);
		System.out.println(buildingController.getAllBuildings());


	}
}