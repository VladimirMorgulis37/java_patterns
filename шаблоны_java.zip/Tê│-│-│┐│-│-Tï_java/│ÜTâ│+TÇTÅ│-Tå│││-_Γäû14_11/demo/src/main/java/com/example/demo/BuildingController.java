package com.example.demo;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
@RestController
@RequestMapping("/buildings")
public class BuildingController {
    private List<Building> buildings = new ArrayList<Building>();
    public Building createBuilding(String creationDate, String type) {
        Building building = new Building(creationDate, type);
        buildings.add(building);
        return building;
    }
    public void deleteBuilding(Building building){
        buildings.remove(building);
    }
    public List<Building> getAllBuildings(){
        return buildings;
    }
}
