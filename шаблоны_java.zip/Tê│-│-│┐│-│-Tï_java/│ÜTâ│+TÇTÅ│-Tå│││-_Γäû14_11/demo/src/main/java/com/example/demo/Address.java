package com.example.demo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Address {
    private String addressText;
    private int zipCode;

    public Address(String addressText, int zipcode) {
        this.addressText = addressText;
        this.zipCode = zipcode;
    }
}
