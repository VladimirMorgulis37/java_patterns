package com.example.demo;

import org.springframework.stereotype.Controller;

import java.util.ArrayList;
import java.util.List;

@Controller
public class AddressController {
    private List<Address> addresses = new ArrayList<Address>();
    public Address createAddress(String addressText, int zipcode) {
        Address address = new Address(addressText, zipcode);
        addresses.add(address);
        return address;
    }
    public void deleteAddress(Address address){
        addresses.remove(address);
    }
    public List<Address> getAllAddresses(){
        return addresses;
    }
}