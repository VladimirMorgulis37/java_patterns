package prototype;

interface Copyable {
    Copyable copy();
}
