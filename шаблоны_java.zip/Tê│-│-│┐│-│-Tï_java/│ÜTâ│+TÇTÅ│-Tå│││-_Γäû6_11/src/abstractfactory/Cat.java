package abstractfactory;

public interface Cat {
    void Meow();
}
