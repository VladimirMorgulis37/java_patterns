package abstractfactory;

public interface Dog {
    void Bark();
    }
