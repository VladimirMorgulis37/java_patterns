package abstractfactory;

public class EnglishCat implements Cat{
    @Override
    public void Meow() {
        System.out.println("meow");
    }
}
