// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
        Developer developer1 = new CppDeveloper();

        developer1.WriteCode();

        Developer developer2 = new JavaDeveloper();

        developer2.WriteCode();
    }
}