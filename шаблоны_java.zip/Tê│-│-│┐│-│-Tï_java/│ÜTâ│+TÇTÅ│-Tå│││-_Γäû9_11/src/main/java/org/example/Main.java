package org.example;

public class  b   xMain {
    public static void main(String[] args) {

        System.out.printf("Hello and welcome!");

    }
}