package com.example.demo;


public class ConsolePrinter implements Printer{

    @Override
    public void doPrint() {
        System.out.println("\n ConsolePrinter begins to run \n");
    }
}