package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication // точка входа
public class DemoApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("aplicationContext.xml");

		Printer printer1 = context.getBean("printerBean1", Printer.class);

		printer1.doPrint();

		Printer printer2 = context.getBean("printerBean2", Printer.class);

		printer2.doPrint();

		SpringApplication.run(DemoApplication.class, args);


	}

}
