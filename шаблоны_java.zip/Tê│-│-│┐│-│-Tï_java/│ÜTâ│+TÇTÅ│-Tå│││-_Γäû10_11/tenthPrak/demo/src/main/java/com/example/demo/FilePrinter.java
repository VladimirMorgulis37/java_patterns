package com.example.demo;

public class FilePrinter implements Printer{
    @Override
    public void doPrint() {
        System.out.println("\n FilePrinter begins to run \n");
    }
}
