package com.example.demo;

public class Senior implements Programmer{
    @Override
    public void doCoding() {
        System.out.println("Сениор сделал отличный код");
    }
}