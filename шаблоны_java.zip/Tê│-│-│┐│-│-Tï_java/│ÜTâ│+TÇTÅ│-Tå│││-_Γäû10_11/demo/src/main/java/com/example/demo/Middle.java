package com.example.demo;

public class Middle implements Programmer{
    @Override
    public void doCoding() {
        System.out.println("Миддл сделал хороший код");
    }
}
