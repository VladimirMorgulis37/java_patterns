package com.example.demo;

public class Junior implements Programmer{
    @Override
    public void doCoding() {
        System.out.println("Джуниор сделал неплохой код");
    }
}
