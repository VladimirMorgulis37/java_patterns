package com.example.laundry.controllers;

import com.example.laundry.models.Building;
import com.example.laundry.services.BuildingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping(value = "/buildings")
public class BuildingController {
    @Autowired
    private BuildingService buildingService;

    @PostMapping
    public @ResponseBody Object createBuilding(@RequestParam Long id,
                                                 @RequestParam String creationDate,
                                                 @RequestParam String type) {
        Building building = new Building(id,creationDate,type);
        return buildingService.createBuilding(building); //SERVICE
    }

    @Transactional
    @DeleteMapping("/{id}")
    public @ResponseBody void deleteBuilding(@PathVariable Long id) {
        buildingService.deleteBuildingById(id);
    }

    @GetMapping
    public @ResponseBody List<Building> getAllBuildings() {
        return buildingService.getAllBuildings();
    }

}