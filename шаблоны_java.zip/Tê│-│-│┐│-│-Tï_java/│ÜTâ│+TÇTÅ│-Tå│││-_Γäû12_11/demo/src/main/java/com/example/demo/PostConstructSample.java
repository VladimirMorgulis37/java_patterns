package com.example.demo;

import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.NoSuchFileException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.io.*;
@Component
public class PostConstructSample {
    @Value("#{springApplicationArguments.nonOptionArgs[0]}")
    private String inputFilePath; //получение из массива конф

    @Value("#{springApplicationArguments.nonOptionArgs[1]}")
    private String outputFilePath; //получение из массива конф

    @PostConstruct
    public void init() {
        try {
            Path file = Path.of(inputFilePath);
            FileWriter writer = new FileWriter(outputFilePath, false);
            try {
            byte[] data = Files.readAllBytes(Paths.get(file.toUri()));
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(data);
            String checksum = new BigInteger(1, hash).toString(16);
                writer.write(checksum);
            } catch (NoSuchFileException e) {
                writer.write("null");
            } finally {
                writer.flush();
            }
        } catch (NoSuchAlgorithmException | IOException e) {}
    }
}