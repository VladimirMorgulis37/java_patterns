package com.example.demo;

public interface Programmer {
    public void doCoding();
}
