package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class DemoApplication {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("aplicationContext.xml");

		Programmer programmer1 = context.getBean("programmerBean1", Programmer.class);

		programmer1.doCoding();

		Programmer programmer2 = context.getBean("programmerBean2", Programmer.class);

		programmer2.doCoding();

		Programmer programmer3 = context.getBean("programmerBean3", Programmer.class);

		programmer3.doCoding();

		SpringApplication.run(DemoApplication.class, args);

	}

}
