package com.example.demo;

public interface Printer {
    void doPrint();
}
