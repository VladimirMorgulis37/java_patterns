package com.example.demo;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Component
public class PreDestroySample {
    @Value("#{springApplicationArguments.nonOptionArgs[0]}")
    private String inputFilePath; //получение из массива конф
    @PreDestroy
    public void destroy() {
            if (Files.exists(Path.of(inputFilePath))) {
                try {
                    Files.delete(Path.of(inputFilePath));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }
    }
