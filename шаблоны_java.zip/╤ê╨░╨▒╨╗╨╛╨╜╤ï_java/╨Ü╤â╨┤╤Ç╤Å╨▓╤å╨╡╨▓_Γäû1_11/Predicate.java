@FunctionalInterface
public interface Predicate<T> {
    boolean test(double x);
}
