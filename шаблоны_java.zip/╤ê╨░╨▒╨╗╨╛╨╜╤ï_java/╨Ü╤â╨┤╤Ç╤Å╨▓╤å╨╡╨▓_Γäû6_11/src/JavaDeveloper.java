public class JavaDeveloper implements Developer {
    @Override
    public void WriteCode() {
        System.out.println("Java Developer writes Java Code");
    }
}
