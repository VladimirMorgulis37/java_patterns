package abstractfactory;

public class SpanishCat implements Cat{
    @Override
    public void Meow() {
        System.out.println("meow");
    }
}
