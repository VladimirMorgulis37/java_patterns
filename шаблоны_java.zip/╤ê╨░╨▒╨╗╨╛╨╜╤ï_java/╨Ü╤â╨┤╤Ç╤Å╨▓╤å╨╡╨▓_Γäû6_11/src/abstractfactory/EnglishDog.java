package abstractfactory;

public class EnglishDog implements Dog {
    @Override
    public void Bark() {
        System.out.println("Bark");
    }
}
