package abstractfactory;

public class SpanishDog implements Dog{
    @Override
    public void Bark() {
        System.out.println("Bark");
    }
}
