public interface Developer {
    void WriteCode();
}
