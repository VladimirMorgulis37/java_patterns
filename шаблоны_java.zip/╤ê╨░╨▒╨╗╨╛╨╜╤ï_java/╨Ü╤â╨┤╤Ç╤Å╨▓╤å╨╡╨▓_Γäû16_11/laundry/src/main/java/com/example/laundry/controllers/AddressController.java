package com.example.laundry.controllers;

import com.example.laundry.models.Address;
import com.example.laundry.services.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@Controller
@RequestMapping(value = "/addresses")
public class AddressController {
    @Autowired
    private final AddressService addressService;

    public AddressController(AddressService addressService) {
        this.addressService = addressService;
    } //SERVICE :3

    @PostMapping
    public @ResponseBody Object createAddress(@RequestBody Address address) {
        return addressService.createAddress(address);
    }

    @GetMapping
    public @ResponseBody List<Address> getAllAddresses() {
        return addressService.getAllAddresses();
    }

    @Transactional
    @DeleteMapping("/{id}")
    public @ResponseBody void deleteAddress(@PathVariable Long id) {
        addressService.deleteAddressById(id);
    }

    @GetMapping("/filter")
    public @ResponseBody List<Address> filterAddresses(@RequestParam(required = false) String addressText,
                                                @RequestParam(required = false) Long buildingId,
                                                @RequestParam(required = false) String zipCode) {
        return addressService.filterAddresses(addressText, buildingId, zipCode);
    }
}
