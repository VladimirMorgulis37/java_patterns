package com.example.laundry.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "addresses")
public class Address {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "address_text")
    private String addressText;

    @Column(name = "zip_code")
    private String zipCode;

    @JsonIgnore
    @ManyToOne()
    @JoinColumn(name = "id_building", referencedColumnName = "id")
    private Building building;

    public Address(Long id, Building building, String addressText, String zipCode) {
        this.id = id;
        this.building = building;
        this.addressText = addressText;
        this.zipCode = zipCode;
    }

    public Address() {}
}
//good
