package com.example.laundry.repositories;

import com.example.laundry.models.Building;
import org.springframework.data.jpa.repository.JpaRepository;


public interface BuildingRepository extends JpaRepository<Building, Long> {

}
//GOOD