package com.example.laundry.repositories;

import com.example.laundry.models.Address;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AddressRepository extends JpaRepository<Address, Long> {

}
//GOOD