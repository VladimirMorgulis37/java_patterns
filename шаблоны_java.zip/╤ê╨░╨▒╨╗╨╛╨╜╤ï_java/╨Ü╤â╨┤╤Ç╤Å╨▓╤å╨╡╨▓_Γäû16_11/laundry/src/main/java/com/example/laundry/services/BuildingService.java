package com.example.laundry.services;

import com.example.laundry.logging.LogTime;
import com.example.laundry.models.Building;
import com.example.laundry.repositories.BuildingRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class BuildingService {
    private final BuildingRepository buildingRepository;

    private static final Logger logger = LoggerFactory.getLogger(BuildingService.class);

    public BuildingService(BuildingRepository buildingRepository) {
        this.buildingRepository = buildingRepository;
    }

    @Transactional
    @LogTime
    public List<Building> getAllBuildings() {
        logger.info("Getting all buildings");
        return buildingRepository.findAll();
    }

    @LogTime
    public Building getBuildingById(Long id) {
        logger.info("Getting building by id: {}", id);
        return buildingRepository.findById(id).orElse(null);
    }

    @LogTime
    public Building createBuilding(Building building) {
        logger.info("Creating building: {}", building);
        return buildingRepository.save(building);
    }

    @LogTime
    public void deleteBuildingById(Long id) {
        logger.info("Deleting building by id: {}", id);
        buildingRepository.deleteById(id);
    }
}