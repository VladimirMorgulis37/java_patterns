package com.example.laundry.services;

import com.example.laundry.logging.LogTime;
import com.example.laundry.models.Address;
import com.example.laundry.models.Building;
import com.example.laundry.repositories.AddressRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class AddressService {

    private final AddressRepository addressRepository;
    private static final Logger logger = LoggerFactory.getLogger(AddressService.class);

    public AddressService(AddressRepository addressRepository) {
        this.addressRepository = addressRepository;
    }

    @LogTime
    public Address createAddress(Address address) {
        logger.debug("Creating address: {}", address);
        Building building = address.getBuilding();
        if (building.getAddresses() == null) {
            building.setAddresses(new ArrayList<>());
        }
        building.getAddresses().add(address); // связываем адрес со зданием
        Address savedAddress = addressRepository.save(address);
        logger.debug("Address created: {}", savedAddress);
        return savedAddress;
    }

    @LogTime
    public List<Address> getAllAddresses() {
        logger.debug("Getting all addresses");
        List<Address> addresses = addressRepository.findAll();
        logger.debug("Found {} addresses", addresses.size());
        return addresses;
    }
    @LogTime
    public void deleteAddressById(Long id) {
        logger.debug("Deleting address with id: {}", id);
        addressRepository.deleteById(id);
        logger.debug("Address with id {} deleted", id);
    }


    @PersistenceContext
    private EntityManager entityManager;

    @LogTime
    public List<Address> filterAddresses(String addressText, Long buildingId, String zipCode) { //17 задание!!!
        logger.debug("Filtering addresses with addressText: {}, buildingId: {}, zipCode: {}", addressText, buildingId, zipCode);
        CriteriaBuilder builder = entityManager.getCriteriaBuilder();
        CriteriaQuery<Address> criteriaQuery = builder.createQuery(Address.class);
        Root<Address> root = criteriaQuery.from(Address.class);
        // создаем пустой список предикатов
        List<Predicate> predicates = new ArrayList<>();
        // добавляем предикаты для каждого переданного параметра
        if (addressText != null) {
            predicates.add(builder.like(root.get("addressText"), "%" + addressText + "%"));
        }
        if (buildingId != null) {
            Join<Address, Building> buildingJoin = root.join("building");
            predicates.add(builder.equal(buildingJoin.get("id"), buildingId));
        }
        if (zipCode != null) {
            predicates.add(builder.equal(root.get("zipCode"), zipCode));
        }
        // добавляем все предикаты в запрос
        criteriaQuery.where(predicates.toArray(new Predicate[predicates.size()]));

        TypedQuery<Address> query = entityManager.createQuery(criteriaQuery);
        List<Address> addresses = query.getResultList();
        logger.debug("Found {} addresses", addresses.size());
        return addresses;
    }
} //Good?