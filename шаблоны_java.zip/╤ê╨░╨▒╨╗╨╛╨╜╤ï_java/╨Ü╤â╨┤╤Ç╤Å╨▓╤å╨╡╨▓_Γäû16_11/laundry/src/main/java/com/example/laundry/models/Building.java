package com.example.laundry.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@Table(name = "buildings")
public class Building {
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "creation_date")
    private String creationDate;

    @Column(name = "type")
    private String type;

    @OneToMany(mappedBy = "building")
    List<Address> addresses;

    public Building(Long id, String creationDate, String type) {
        this.id=id;
        this.creationDate = creationDate;
        this.type = type;
    }

    public Building() {}
}
//GOOD